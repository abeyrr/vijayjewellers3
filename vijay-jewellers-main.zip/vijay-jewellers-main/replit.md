# Vijay Jewellers - E-commerce Platform

## Overview

This is a luxury jewellery e-commerce platform for "Vijay Jewellers," a business specializing in gold, silver, one gram gold, and 92.5 sterling silver jewellery. The application showcases product collections, allows filtering by material and category, and provides detailed product views with contact information for purchases.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state caching and synchronization
- **Styling**: Tailwind CSS with custom luxury theme (gold, cream, charcoal palette)
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Animations**: Framer Motion for page transitions and scroll effects
- **Build Tool**: Vite with HMR support

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript (ESM modules)
- **API Pattern**: RESTful endpoints defined in `shared/routes.ts` with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Development**: Hot module replacement via Vite middleware integration

### Data Storage
- **Database**: PostgreSQL (connection via `DATABASE_URL` environment variable)
- **Schema Definition**: Drizzle schema in `shared/schema.ts`
- **Migrations**: Drizzle Kit for schema migrations (`db:push` command)
- **Current Schema**: Products table with id, name, description, price, material, category, and imageUrl fields

### Project Structure
```
├── client/           # React frontend application
│   └── src/
│       ├── components/   # UI components (shadcn + custom)
│       ├── pages/        # Route components (Home, Collection, ProductDetail, About)
│       ├── hooks/        # Custom hooks (use-products, use-toast)
│       └── lib/          # Utilities and query client
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route handlers
│   ├── storage.ts    # Database abstraction layer
│   └── db.ts         # Drizzle database connection
├── shared/           # Shared code between client/server
│   ├── schema.ts     # Drizzle database schema
│   └── routes.ts     # API route definitions with Zod schemas
└── migrations/       # Database migration files
```

### API Design
Routes are defined declaratively in `shared/routes.ts` with:
- Path definitions with parameter placeholders
- Zod schemas for request/response validation
- Type-safe URL building via `buildUrl` helper

Current endpoints:
- `GET /api/products` - List products with optional material/category filters
- `GET /api/products/:id` - Get single product by ID

### Build & Deployment
- **Development**: `npm run dev` runs Vite dev server with Express backend
- **Production Build**: `npm run build` creates optimized bundles using esbuild for server and Vite for client
- **Static Serving**: Production serves built frontend from `dist/public`

## External Dependencies

### Database
- **PostgreSQL**: Primary database, configured via `DATABASE_URL` environment variable
- **Connection Pooling**: Uses `pg` Pool for connection management

### UI Libraries
- **Radix UI**: Complete set of accessible, unstyled UI primitives
- **Lucide React**: Icon library
- **Embla Carousel**: Carousel component for product galleries

### Development Tools
- **Replit Plugins**: Runtime error overlay, cartographer, and dev banner for Replit environment
- **TypeScript**: Strict mode enabled with path aliases (@/, @shared/, @assets/)

### Fonts
- **Playfair Display**: Serif display font for headings
- **Montserrat**: Sans-serif body font
- Loaded via Google Fonts CDN
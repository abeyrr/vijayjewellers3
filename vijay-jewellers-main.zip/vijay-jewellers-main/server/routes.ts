import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.products.list.path, async (req, res) => {
    const material = req.query.material as string | undefined;
    const category = req.query.category as string | undefined;
    const products = await storage.getProducts(material, category);
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  });

  // Seed data endpoint (internal use or auto-run)
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getProducts();
  if (existing.length > 0) return;

  const seedProducts = [
    {
      name: "Classic Gold Necklace",
      description: "22k Gold necklace with intricate design.",
      price: 45000,
      material: "Gold",
      category: "Necklace",
      imageUrl: "https://images.unsplash.com/photo-1599643478518-17488fbbcd75?w=600&q=80"
    },
    {
      name: "Silver Stud Earrings",
      description: "92.5 Sterling Silver stud earrings.",
      price: 2500,
      material: "92.5 Silver",
      category: "Earrings",
      imageUrl: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&q=80"
    },
    {
      name: "Rose Gold Plated Bangle",
      description: "One Gram Gold plated bangle with rose gold finish.",
      price: 1200,
      material: "One Gram Gold",
      category: "Bangle",
      imageUrl: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&q=80"
    },
    {
      name: "Traditional Gold Jhumka",
      description: "Traditional design One Gram Gold Jhumka.",
      price: 1500,
      material: "One Gram Gold",
      category: "Earrings",
      imageUrl: "https://images.unsplash.com/photo-1588444837495-c6cfeb53f32d?w=600&q=80"
    },
    {
      name: "Silver Anklet",
      description: "Delicate 92.5 Silver anklet.",
      price: 1800,
      material: "92.5 Silver",
      category: "Anklet",
      imageUrl: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&q=80"
    },
    {
      name: "Diamond Studded Gold Ring",
      description: "18k Gold ring with small diamond accents.",
      price: 35000,
      material: "Gold",
      category: "Ring",
      imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&q=80"
    },
    {
      name: "Silver Oxidized Choker",
      description: "Handcrafted oxidized silver choker.",
      price: 4500,
      material: "Silver",
      category: "Necklace",
      imageUrl: "https://images.unsplash.com/photo-1603974372039-adc49044b6bd?w=600&q=80"
    }
  ];

  for (const p of seedProducts) {
    await storage.createProduct(p);
  }
}

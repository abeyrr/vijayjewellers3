import { useParams } from "wouter";
import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";
import { Loader2 } from "lucide-react";
import { useState } from "react";

const MATERIAL_MAP: Record<string, string> = {
  "gold": "Gold",
  "silver": "Silver",
  "one-gram-gold": "One Gram Gold",
  "92.5-silver": "92.5 Silver"
};

const MATERIAL_TITLES: Record<string, string> = {
  "gold": "Pure Gold Collection",
  "silver": "Sterling Silver",
  "one-gram-gold": "One Gram Gold",
  "92.5-silver": "92.5 Sterling Silver"
};

const CATEGORIES = ["All", "Necklace", "Earrings", "Ring", "Bangle", "Bracelet"];

export default function Collection() {
  const { material } = useParams();
  const [selectedCategory, setSelectedCategory] = useState("All");
  
  const mappedMaterial = material && MATERIAL_MAP[material] ? MATERIAL_MAP[material] : undefined;
  
  const { data: products, isLoading } = useProducts({
    material: mappedMaterial,
    category: selectedCategory === "All" ? undefined : selectedCategory
  });

  if (!mappedMaterial) {
    return <div className="pt-32 text-center">Collection not found</div>;
  }

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <div className="bg-secondary/30 py-16 md:py-24 text-center border-b border-border/50">
        <h1 className="font-display text-4xl md:text-5xl font-medium text-foreground capitalize mb-4">
          {MATERIAL_TITLES[material!] || "Collection"}
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto px-4">
          Explore our handcrafted range of {mappedMaterial} jewellery, designed to make every moment special.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {/* Filters */}
        <div className="flex flex-wrap gap-3 justify-center mb-12">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                selectedCategory === cat
                  ? "bg-primary text-white shadow-md shadow-primary/20"
                  : "bg-white border border-border text-muted-foreground hover:border-primary/50 hover:text-primary"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : products?.length === 0 ? (
          <div className="text-center py-20 bg-secondary/10 rounded-lg border border-dashed border-border">
            <p className="text-muted-foreground text-lg">No products found in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products?.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

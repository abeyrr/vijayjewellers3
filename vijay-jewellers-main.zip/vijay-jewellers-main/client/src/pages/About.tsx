export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <div className="relative h-[60vh] overflow-hidden">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: `url('https://images.unsplash.com/photo-1531995811006-35cb42e1a022?q=80&w=2000&auto=format&fit=crop')` 
          }}
        />
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-center px-4">
          <h1 className="font-display text-5xl md:text-7xl font-bold text-white mb-6">Our Legacy</h1>
          <p className="text-white/90 text-xl font-light max-w-2xl">
            Crafting stories in gold and silver for nearly five decades.
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 space-y-16">
        <div className="text-center space-y-6">
          <span className="text-primary text-sm tracking-widest uppercase font-semibold">Since 1976</span>
          <h2 className="font-display text-3xl md:text-4xl font-medium">The Art of Jewellery Making</h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            At Vijay Jewellers, we believe jewellery is more than just adornment—it is a personal statement, 
            a family heirloom, and a timeless investment. Founded with a passion for exquisite craftsmanship, 
            we have established ourselves as a premier destination for high-quality gold, silver, and 
            one-gram gold jewellery.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="aspect-square bg-secondary rounded-lg overflow-hidden">
             <img 
              src="https://pixabay.com/get/gbc77fd29898e3d616658ee429d05352193cc553bfafa84f5a0f3b76a9514de64e7e45c4d10fcaf612bd0bbd3cc79de3bf318de70556710d02f5a40b793f7903c_1280.jpg" 
              alt="Craftsmanship" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="space-y-6">
            <h3 className="font-display text-2xl font-medium">Uncompromising Quality</h3>
            <p className="text-muted-foreground leading-relaxed">
              Each piece in our collection undergoes rigorous quality checks. Our gold is hallmarked for purity, 
              and our silver is the finest sterling grade. We work with master artisans who combine traditional 
              techniques with modern aesthetics to create designs that are both classic and contemporary.
            </p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center"><span className="w-1.5 h-1.5 bg-primary rounded-full mr-3" /> 100% Hallmarked Gold</li>
              <li className="flex items-center"><span className="w-1.5 h-1.5 bg-primary rounded-full mr-3" /> Authentic 92.5 Sterling Silver</li>
              <li className="flex items-center"><span className="w-1.5 h-1.5 bg-primary rounded-full mr-3" /> Premium One Gram Gold Plating</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useParams, Link } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { Loader2, Phone, Shield, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function ProductDetail() {
  const { id } = useParams();
  const { data: product, isLoading, error } = useProduct(Number(id));
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [mainImage, setMainImage] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center space-y-4">
        <h2 className="text-2xl font-display">Product not found</h2>
        <Link href="/" className="text-primary hover:underline">Back to Home</Link>
      </div>
    );
  }

  const formattedPrice = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(product.price);

  return (
    <div className="min-h-screen bg-white pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-primary transition-colors">Home</Link>
          <span className="mx-2">/</span>
          <Link href={`/collection/${product.material.toLowerCase().replace(/ /g, '-')}`} className="hover:text-primary transition-colors">
            {product.material}
          </Link>
          <span className="mx-2">/</span>
          <span className="text-foreground font-medium truncate">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Image Section */}
          <div className="space-y-6">
            <div className="group relative aspect-[4/5] bg-secondary/10 rounded-lg overflow-hidden border border-border/50 cursor-zoom-in">
              <img 
                src={mainImage || product.imageUrl} 
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-150"
                onMouseMove={(e) => {
                  const target = e.currentTarget;
                  const rect = target.getBoundingClientRect();
                  const x = ((e.clientX - rect.left) / rect.width) * 100;
                  const y = ((e.clientY - rect.top) / rect.height) * 100;
                  target.style.transformOrigin = `${x}% ${y}%`;
                }}
              />
            </div>
            
            {product.additionalImages && product.additionalImages.length > 0 && (
              <div className="grid grid-cols-4 gap-4">
                <div 
                  onClick={() => setMainImage(product.imageUrl)}
                  className={cn(
                    "aspect-square bg-secondary/10 rounded-md overflow-hidden border-2 cursor-pointer transition-all",
                    (mainImage === null || mainImage === product.imageUrl) ? "border-primary shadow-md" : "border-transparent opacity-70 hover:opacity-100"
                  )}
                >
                  <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                </div>
                {product.additionalImages.map((img, idx) => (
                  <div 
                    key={idx}
                    onClick={() => setMainImage(img)}
                    className={cn(
                      "aspect-square bg-secondary/10 rounded-md overflow-hidden border-2 cursor-pointer transition-all",
                      mainImage === img ? "border-primary shadow-md" : "border-transparent opacity-70 hover:opacity-100"
                    )}
                  >
                    <img src={img} alt={`${product.name} view ${idx + 1}`} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Details Section */}
          <div className="flex flex-col justify-center space-y-8">
            <div className="space-y-4 border-b border-border pb-8">
              <span className="text-sm font-medium tracking-widest text-primary uppercase">{product.category}</span>
              <h1 className="font-display text-4xl md:text-5xl font-medium text-foreground">{product.name}</h1>
              <p className="text-2xl font-semibold text-primary">{formattedPrice}</p>
            </div>

            <div className="space-y-6">
              <p className="text-muted-foreground leading-relaxed text-lg font-light">
                {product.description}
              </p>

              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="p-4 bg-secondary/20 rounded border border-border/50">
                  <span className="block text-xs uppercase tracking-wider text-muted-foreground mb-1">Material</span>
                  <span className="font-medium text-foreground">{product.material}</span>
                </div>
                <div className="p-4 bg-secondary/20 rounded border border-border/50">
                  <span className="block text-xs uppercase tracking-wider text-muted-foreground mb-1">Purity</span>
                  <span className="font-medium text-foreground">Certified Authentic</span>
                </div>
              </div>

              <div className="flex items-center space-x-2 text-sm text-green-700 bg-green-50 px-4 py-3 rounded-md border border-green-100">
                <Shield className="w-4 h-4" />
                <span>Includes Certificate of Authenticity & Lifetime Warranty</span>
              </div>

              <Dialog open={isContactOpen} onOpenChange={setIsContactOpen}>
                <DialogTrigger asChild>
                  <Button 
                    size="lg" 
                    className="w-full h-14 text-lg font-medium bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20"
                  >
                    Contact to Buy
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="font-display text-2xl">Interested in this piece?</DialogTitle>
                    <DialogDescription>
                      Our jewellery experts are ready to assist you with your purchase. Call or WhatsApp us directly.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="flex items-center p-4 bg-secondary/20 rounded-lg">
                      <Phone className="w-5 h-5 text-primary mr-3" />
                      <div>
                        <p className="font-medium">Call Us</p>
                        <p className="text-sm text-muted-foreground">+91 98765 43210</p>
                      </div>
                    </div>
                    <div className="text-center text-sm text-muted-foreground mt-2">
                      Please mention Product ID: <span className="font-mono text-foreground font-medium">#{product.id}</span>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button variant="outline" onClick={() => setIsContactOpen(false)}>Close</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

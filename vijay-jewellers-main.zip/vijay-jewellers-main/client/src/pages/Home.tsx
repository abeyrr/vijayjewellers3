import { Link } from "wouter";
import { ArrowRight, Star, ShieldCheck, Truck } from "lucide-react";
import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";
import { motion } from "framer-motion";

const CATEGORIES = [
  {
    title: "Sterling Silver",
    image: "https://images.unsplash.com/photo-1602752250015-407481ec627c?q=80&w=800&auto=format&fit=crop",
    href: "/collection/silver",
    desc: "Contemporary silver designs"
  },
  {
    title: "One Gram Gold",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop",
    href: "/collection/one-gram-gold",
    desc: "Affordable luxury for daily wear"
  },
  {
    title: "92.5 Silver",
    image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=800&auto=format&fit=crop",
    href: "/collection/92.5-silver",
    desc: "Pure sterling silver elegance"
  },
];

export default function Home() {
  const { data: featuredProducts, isLoading } = useProducts();

  return (
    <div className="min-h-screen">
      {/* Brand Banner */}
      <section className="w-full bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 border-b border-primary/20 py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-4"
          >
            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-primary tracking-tight">
              VIJAY JEWELLERS
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground font-light tracking-wide max-w-2xl mx-auto">
              Crafting Timeless Elegance Since 1976
            </p>
            <div className="flex justify-center gap-2 pt-4">
              <div className="w-1.5 h-1.5 rounded-full bg-primary/40" />
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <div className="w-1.5 h-1.5 rounded-full bg-primary/40" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Hero Section */}
      <section className="relative h-[85vh] w-full overflow-hidden bg-secondary">
        {/* Abstract luxury background */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30 z-10" />
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: `url('https://images.unsplash.com/photo-1573408301185-9146fe634ad0?q=80&w=2000&auto=format&fit=crop')` 
          }}
        />
        
        <div className="relative z-20 h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-start">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-2xl text-white space-y-6"
          >
            <span className="text-gold tracking-[0.2em] text-sm uppercase font-semibold">Exquisite Collection 2024</span>
            <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight">
              Elegance in <br /> Every Detail
            </h1>
            <p className="text-lg md:text-xl text-white/80 font-light max-w-lg leading-relaxed">
              Discover our curated selection of fine gold and silver jewellery, crafted to perfection for the modern connoisseur.
            </p>
            <div className="pt-8">
              <Link 
                href="/collection/gold" 
                className="inline-flex items-center px-8 py-4 bg-white text-foreground hover:bg-gold hover:text-white transition-all duration-300 rounded-sm font-medium tracking-wide"
              >
                Shop Collection <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Banner */}
      <section className="bg-primary/5 py-12 border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center space-y-2">
              <div className="p-3 bg-white rounded-full shadow-sm text-primary mb-2">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-display font-medium text-lg">Certified Authenticity</h3>
              <p className="text-sm text-muted-foreground">Every piece comes with a hallmark certificate</p>
            </div>
            <div className="flex flex-col items-center space-y-2">
              <div className="p-3 bg-white rounded-full shadow-sm text-primary mb-2">
                <Truck className="w-6 h-6" />
              </div>
              <h3 className="font-display font-medium text-lg">Secure Shipping</h3>
              <p className="text-sm text-muted-foreground">Insured delivery across India</p>
            </div>
            <div className="flex flex-col items-center space-y-2">
              <div className="p-3 bg-white rounded-full shadow-sm text-primary mb-2">
                <Star className="w-6 h-6" />
              </div>
              <h3 className="font-display font-medium text-lg">Lifetime Support</h3>
              <p className="text-sm text-muted-foreground">Cleaning and maintenance services</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-primary text-sm tracking-widest uppercase font-semibold">Our Collections</span>
          <h2 className="font-display text-4xl mt-3 font-medium">Curated For You</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {CATEGORIES.map((category, idx) => (
            <Link key={idx} href={category.href} className="group relative h-96 overflow-hidden rounded-lg cursor-pointer">
              <img 
                src={category.image} 
                alt={category.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center">
                <h3 className="font-display text-3xl mb-2">{category.title}</h3>
                <p className="text-white/80 font-light text-sm mb-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                  {category.desc}
                </p>
                <span className="border-b border-white pb-1 text-sm tracking-widest uppercase hover:text-gold hover:border-gold transition-colors">
                  Explore
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-secondary/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="text-primary text-sm tracking-widest uppercase font-semibold">New Arrivals</span>
              <h2 className="font-display text-3xl mt-2 font-medium">Latest Masterpieces</h2>
            </div>
            <Link href="/collection/gold" className="hidden md:flex items-center text-sm font-medium hover:text-primary transition-colors">
              View All <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="space-y-4 animate-pulse">
                  <div className="bg-gray-200 h-80 rounded-lg w-full" />
                  <div className="h-4 bg-gray-200 w-3/4 rounded" />
                  <div className="h-4 bg-gray-200 w-1/2 rounded" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts?.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
          
          <div className="mt-12 text-center md:hidden">
            <Link href="/collection/gold" className="inline-flex items-center text-sm font-medium border border-border px-6 py-3 rounded hover:bg-white transition-colors">
              View All Products
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

import { Facebook, Instagram, Twitter, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-secondary/30 pt-16 pb-8 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          
          <div className="space-y-4">
            <h3 className="font-display text-xl font-bold text-primary">VIJAY JEWELLERS</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Crafting timeless elegance since 1976. We specialize in exquisite gold and silver jewellery that celebrates life's most precious moments.
            </p>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4 text-foreground">Collections</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="/collection/silver" className="hover:text-primary transition-colors">Sterling Silver</a></li>
              <li><a href="/collection/one-gram-gold" className="hover:text-primary transition-colors">One Gram Gold</a></li>
              <li><a href="/collection/92.5-silver" className="hover:text-primary transition-colors">92.5 Silver</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4 text-foreground">Contact & Support</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary" />
                <a href="tel:+917376397000" className="hover:text-primary transition-colors">+91 7376397000</a>
              </li>
              <li><a href="#" className="hover:text-primary transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Size Guide</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4 text-foreground">Connect</h4>
            <div className="flex space-x-4 text-muted-foreground">
              <a href="#" className="hover:text-primary transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="hover:text-primary transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="hover:text-primary transition-colors"><Twitter className="w-5 h-5" /></a>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              Subscribe to our newsletter for exclusive offers.
            </p>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-border/50 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Vijay Jewellers. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

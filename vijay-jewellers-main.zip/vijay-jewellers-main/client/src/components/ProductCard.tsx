import { Link } from "wouter";
import { type ProductResponse } from "@shared/routes";
import { ArrowRight } from "lucide-react";

interface ProductCardProps {
  product: ProductResponse;
}

export function ProductCard({ product }: ProductCardProps) {
  // Format price to INR
  const formattedPrice = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(product.price);

  return (
    <Link href={`/product/${product.id}`} className="group block cursor-pointer">
      <div className="relative overflow-hidden bg-white rounded-lg shadow-sm luxury-border aspect-[3/4]">
        <img 
          src={product.imageUrl} 
          alt={product.name}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
        
        {/* Quick View Button on Hover */}
        <div className="absolute bottom-4 right-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
          <div className="bg-white/90 backdrop-blur text-primary p-2 rounded-full shadow-lg">
            <ArrowRight className="w-5 h-5" />
          </div>
        </div>
      </div>
      
      <div className="mt-4 space-y-1">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">{product.category}</p>
        <h3 className="font-display text-lg font-medium text-foreground group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        <p className="text-sm font-semibold text-primary">{formattedPrice}</p>
      </div>
    </Link>
  );
}

## Packages
framer-motion | For elegant page transitions and scroll animations
lucide-react | Beautiful icons for UI elements

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
